<!-- <div class="header-top">
<p>This is the product of AppDupe ( from Tranxit Technologies Solutions ) Please do not purchase This Product from any fraudulent sources. For any assistance, please contact info@appdupe.com<span class="cross-icon pull-right"><i class="fa fa-times"></i></span></p> 
</div> -->
